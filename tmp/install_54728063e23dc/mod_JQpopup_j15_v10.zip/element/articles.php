<?php
/*------------------------------------------------------------------------
# mod_JQpopup - Jquery UI Popup Module
# ------------------------------------------------------------------------
# author    Vsmart Extensions
# copyright Copyright (C) 2010 YourAwesomeSite.com. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://www.vsmart-extensions.com
# Technical Support:  Forum - http://www.vsmart-extensions.com
-------------------------------------------------------------------------*/
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
	class JElementArticles extends JElement {

	  	var   $_name = 'articles';

		function fetchElement($name, $value, &$node, $control_name)
		{
			$db = &JFactory::getDBO();

			$section	= $node->attributes('section');
			$class		= $node->attributes('class');
			if (!$class) {
				$class = "inputbox";
			}

			if (!isset ($section)) {
				$section = $node->attributes('scope');
				if (!isset ($section)) {
					$section = 'content';
				}
			}

			if ($section == 'content') {
				$query = 'SELECT c.id, c.title AS title' .
					' FROM #__content AS c' .
					' WHERE c.state = 1' .
					' ORDER BY c.title';
			}
			$db->setQuery($query);
			$options = $db->loadObjectList();
			$result = '<select name="'.$control_name.'['.$name.'][]" id="'.$name.'" class="'.$class.'" >';
			
			foreach( $options as $option ) {
				if(is_array( $value) ) {
					if( in_array( $option->id, $value ) ) {
						$result .= '<option selected="true" value="'.$option->id.'" >'.$option->title.'</option>';
					} else {
						$result .= '<option value="'.$option->id.'" >'.$option->title.'</option>';
					}
				} elseif ( $value ) {
					if( $value == $option->id ) {
						$result .= '<option selected="true" value="'.$option->id.'" >'.$option->title.'</option>';
					} else {
						$result .= '<option value="'.$option->id.'" >'.$option->title.'</option>';
					}
				} elseif ( !( $value ) ) {
					$result .= '<option value="'.$option->id.'" >'.$option->title.'</option>';
				}
			}
			$result .= '</select>';
			return $result;

		}
	}

?>