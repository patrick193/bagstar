<?php
/**
 * @package SjClass
 * @subpackage SjVmReader
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @copyright (c) 2009-2011 YouTech Company. All Rights Reserved.
 * @author YouTech Company http://www.smartaddons.com
 *
 */

defined('_YTOOLS') or die;

if (!class_exists('SjSpReader')){
	class SjVmReader{
		private $_categories;
		private $_items;

	}
}